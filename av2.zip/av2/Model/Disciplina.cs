﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class Disciplina
    {
        public Int32 codigo { set; get; }

        public String descricao { set; get; }
    }
}
