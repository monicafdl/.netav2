﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class Diario
    {
        public Int32 codigo { set; get; }
        public Disciplina Diario_Disciplina { set; get; }
        public Avaliacao Diario_Avaliacao { set; get; }
        public List<AlunoDAO> Diario_Alunos { set; get; }
    }
}
