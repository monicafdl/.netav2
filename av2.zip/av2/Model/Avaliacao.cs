﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class Avaliacao
    {
        #region Atributos

        public Int32 codigo { set; get; }

        public Int32 valor { set; get; }
        public Diario Ava_Diario { set; get; }
        public AlunoDAO Ava_Aluno { set; get; }

        #endregion

        #region Métodos
        //Implementação dos métodos
        public Avaliacao()
        {
            this.Enderecos = new List<Diario>();
        }

        #endregion
    }
}
