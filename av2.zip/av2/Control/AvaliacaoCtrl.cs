﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;
using Dao;

namespace Control
{
    public class AvaliacaoCtrl
    {
        public Boolean InserirBD(Avaliacao _objeto)
        {
            bool resultado = false;
            try
            {
                AvaliacaoDAO dao = new AvaliacaoDAO();

                return dao.InserirBDParametros(_objeto);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
