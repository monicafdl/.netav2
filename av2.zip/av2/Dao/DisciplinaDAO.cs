﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;
using System.Data.SqlServerCe;

namespace Dao
{
    public class EnderecoDAO
    {
        public List<Diario> ListarTodos()
        {
            List<Diario> listaEnderecos = new List<Diario>();
            try
            {
                String SQL = "SELECT * FROM endereco;";

                SqlCeDataReader data = BD.ExecutarSelect(SQL);

                while (data.Read())
                {
                    Diario e = new Diario();

                    e.Id = data.GetInt32(0);
                    e.Logradouro = data.GetString(1);

                    listaEnderecos.Add(e);
                }

                data.Close();
                BD.FecharConexao();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            return listaEnderecos;
        }

        public Diario BuscarPorID(Int64 _id)
        {
            Diario e = null;
            try
            {
                String SQL = String.Format("SELECT * FROM endereco WHERE id = {0} ", _id);

                SqlCeDataReader data = BD.ExecutarSelect(SQL);

                if (data.Read())
                {
                    e = new Diario();

                    e.Id = data.GetInt32(0);
                    e.Logradouro = data.GetString(1);
                }

                data.Close();
                BD.FecharConexao();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            return e;
        }

        public Boolean InserirBD(Diario _objeto)
        {
            bool resultado = false;
            try
            {
                String SQL = String.Format("INSERT INTO endereco (descricao) VALUES ('{0}')", _objeto.Logradouro);

                int linhaAfetadas = BD.ExecutarIDU(SQL);

                if (linhaAfetadas > 0)
                {
                    return true;
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            return resultado;
        }

        public Boolean AlterarBD(Diario _objeto)
        {
            bool resultado = false;
            try
            {
                String SQL = String.Format("UPDATE endereco SET descricao = '{0}' WHERE id = {1};",
                    _objeto.Logradouro,
                    _objeto.Id);

                int linhaAfetadas = BD.ExecutarIDU(SQL);

                if (linhaAfetadas > 0)
                {
                    return true;
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            return resultado;
        }

        public Boolean DeletarBD(Int64 _id)
        {
            bool resultado = false;
            try
            {
                String SQL = String.Format("DELETE FROM endereco WHERE id = {0};", _id);

                int linhaAfetadas = BD.ExecutarIDU(SQL);

                if (linhaAfetadas > 0)
                {
                    return true;
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            return resultado;
        }

        public List<Diario> BuscarEnderecosPorPessoa(Int64 _idPessoa)
        {
            List<Diario> listaEnderecos = new List<Diario>();
            try
            {
                String SQL = String.Format("SELECT * FROM endereco WHERE pessoa_id = {0};", _idPessoa);

                SqlCeDataReader data = BD.ExecutarSelect(SQL);

                while (data.Read())
                {
                    Diario e = new Diario();

                    e.Id = data.GetInt32(0);
                    e.Logradouro = data.GetString(1);
                    e.Numero = data.GetString(2);
                    e.Bairro = data.GetString(3);

                    e.Cidade.Id = data.GetInt32(4);

                    listaEnderecos.Add(e);
                }

                data.Close();
                BD.FecharConexao();

                foreach (Diario end in listaEnderecos)
                {
                    CidadeDAO dao = new CidadeDAO();

                    end.Cidade = dao.BuscarCidadePorID(end.Cidade.Id);
                }

                return listaEnderecos;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
