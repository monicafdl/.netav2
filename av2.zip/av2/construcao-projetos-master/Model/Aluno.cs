﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class Aluno
    {
        public Int32 matricula { set; get; }

        //Declaração Implícita
        public String Nome { set; get; }
        internal Diario Aluno_Diario { set; get; }
        internal List<Avaliacao> Aluno_Avaliacoes { set; get; }
    }
}
