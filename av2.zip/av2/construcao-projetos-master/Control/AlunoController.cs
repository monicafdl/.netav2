﻿using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dao;

namespace Control
{
    public class AlunoController
    {
        public Object ExecutarOpBD(char _c, Aluno _o)
        {
            try
            {
                Int32 codAluno = _o.Aluno.Codigo;

                CidadeDAO dao = new CidadeDAO();
                switch (_c)
                {
                    case 'i':
                        return dao.Inserir(_o);
                    case 'd':
                        return dao.Deletar(_o.Codigo);
                    case 'a':
                        return dao.Atualizar(_o);
                    case 't':
                        return dao.BuscarCidadesPorEstado(codAluno);
                    case 'o':
                        return dao.BuscarCidadePorID(_o.Codigo);
                    default:
                        return null;
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
