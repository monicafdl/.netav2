﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;
using Dao;

namespace Control
{
    public class DisciplinaController
    {
        public Object ExecutarOpBD(char _c, Disciplina _o)
        {
            try
            {
                
                switch (_c)
                {
                    case 'i':
                        return dao.Inserir(_o);
                    case 'd':
                        return dao.Deletar(_o.Codigo);
                    case 'a':
                        return dao.Atualizar(_o);
                    case 't':
                        return dao.ListarTodos();
                    case 'o':
                        return dao.BuscarPorID(_o.Codigo);
                    default:
                        return null;
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
