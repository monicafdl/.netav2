﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;
using System.Data.SqlServerCe;

namespace Dao
{
    public class DiarioDAO
    {
        public Diario BuscarPorID(Int64 _id)
        {
            Diario d = null;
            try
            {
                String SQL = String.Format("SELECT * FROM Diario WHERE id = {0} ", _id);

                SqlCeDataReader data = BD.ExecutarSelect(SQL);

                if (data.Read())
                {
                    d = new Diario();

                    d.codigo = data.GetInt32(0);
                    
                    AlunoDAO daoA = new AlunoDAO();

                    d.Diario_Alunos = daoA.BuscarAlunoPorDiario(d.codigo);

                    


                    
                }

                data.Close();
                BD.FecharConexao();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            return e;
        }

        public Boolean InserirBD(Diario _objeto)
        {
            bool resultado = false;
            try
            {
                String SQL = String.Format("INSERT INTO Diario (codigo) VALUES ('{0}')", _objeto.codigo);

                int linhaAfetadas = BD.ExecutarIDU(SQL);

                if (linhaAfetadas > 0)
                {
                    return true;
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            return resultado;
        }

        public Boolean AlterarBD(Diario _objeto)
        {
            bool resultado = false;
            try
            {
                String SQL = String.Format("UPDATE Diario SET descricao = '{0}' WHERE id = {1};",
                    _objeto.Logradouro,
                    _objeto.Id);

                int linhaAfetadas = BD.ExecutarIDU(SQL);

                if (linhaAfetadas > 0)
                {
                    return true;
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            return resultado;
        }

        public Boolean DeletarBD(Int64 _cod)
        {
            bool resultado = false;
            try
            {
                String SQL = String.Format("DELETE FROM Diario WHERE codigo = {0};", _cod);

                int linhaAfetadas = BD.ExecutarIDU(SQL);

                if (linhaAfetadas > 0)
                {
                    return true;
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            return resultado;
        }

        public List<Diario> BuscarDiariosPorAluno(Int64 _idPessoa)
        {
            List<Diario> listaDiarios = new List<Diario>();
            try
            {
                String SQL = String.Format("SELECT * FROM Diario WHERE pessoa_id = {0};", _idPessoa);

                SqlCeDataReader data = BD.ExecutarSelect(SQL);

                while (data.Read())
                {
                    Diario e = new Diario();

                    e.Id = data.GetInt32(0);
                    e.Logradouro = data.GetString(1);
                    e.Numero = data.GetString(2);
                    e.Bairro = data.GetString(3);

                    e.Cidade.Id = data.GetInt32(4);

                    listaDiarios.Add(e);
                }

                data.Close();
                BD.FecharConexao();

                foreach (Diario end in listaDiarios)
                {
                    CidadeDAO dao = new CidadeDAO();

                    end.Cidade = dao.BuscarCidadePorID(end.Cidade.Id);
                }

                return listaDiarios;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
