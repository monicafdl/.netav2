﻿using System;
using System.Collections.Generic;
using System.Data.SqlServerCe;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;

namespace Dao
{
    public class AlunoDAO
    {
        public List<Aluno> BuscarAlunosPorAvaliacao(Int32 _codAva)
        {
            List<Aluno> listaCidades = new List<Aluno>();
            try
            {
                String SQL = String.Format("SELECT * FROM aluno WHERE avaliacao_id = {0};", _coAva);

                SqlCeDataReader data = BD.ExecutarSelect(SQL);

                while (data.Read())
                {
                    Aluno a = new Aluno();

                    a.matricula = data.GetInt32(0);
                    a.Nome = data.GetString(1);


                    listaCidades.Add(a);
                }

                data.Close();
                BD.FecharConexao();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            return listaCidades;
        }

        public Aluno BuscarCidadePorID(Int32 _id)
        {
            Aluno c = null;
            try
            {
                String SQL = String.Format("SELECT * FROM cidade WHERE id = {0} ", _id);

                SqlCeDataReader data = BD.ExecutarSelect(SQL);

                if (data.Read())
                {
                    c = new Aluno();

                    c.Id = data.GetInt32(0);
                    c.Descricao = data.GetString(1);
                }

                data.Close();
                BD.FecharConexao();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            return c;
        }

        public object Inserir(Aluno _o)
        {
            throw new NotImplementedException();
        }

        public object Deletar(int p)
        {
            throw new NotImplementedException();
        }

        public object Atualizar(Aluno _o)
        {
            throw new NotImplementedException();
        }
    }
}
