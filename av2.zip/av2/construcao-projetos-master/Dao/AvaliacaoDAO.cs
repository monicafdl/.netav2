﻿using Model;
using System;
using System.Collections.Generic;
using System.Data.SqlServerCe;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dao
{
    public class AvaliacaoDAO
    {

        public List<Avaliacao> ListarTodos()
        {
            List<Avaliacao> listaAvaliacoes = new List<Avaliacao>();
            try
            {
                String SQL = "SELECT * FROM pessoa;";

                SqlCeDataReader data = BD.ExecutarSelect(SQL);

                while (data.Read())
                {
                    Avaliacao a = new Avaliacao();

                    a.codigo = data.GetInt32(0);
                    a.valor = data.GetInt32(1);
                    DiarioDAO daoD = new DiarioDAO();
                    a.Ava_Diario = daoD.BuscarDiarioPorAvaliacao(a.codigo);

                    listaAvaliacoes.Add(a);
                }

                data.Close();
                BD.FecharConexao();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            return listaAvaliacoes;
        }

        public Avaliacao BuscarPorID(Int64 _id)
        {
            Avaliacao a = null;
            try
            {
                String SQL = String.Format("SELECT * FROM pessoa WHERE codigo = {0} ", _id);

                SqlCeDataReader data = BD.ExecutarSelect(SQL);

                if (data.Read())
                {
                    a = new Avaliacao();

                    a.codigo = data.GetInt32(0);
                    a.valor = data.GetInt32(1);
                    AlunoDAO daoA = new AlunoDAO();
                    a.Ava_Aluno = daoA.BuscarAlunosPorAvaliacao(a.codigo);
                    DiarioDAO daoD = new DiarioDAO();
                    a.Ava_Diario = daoD.BuscarDiarioPorAvaliacao(a.codigo);
                }

                data.Close();
                BD.FecharConexao();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            return a;
        }

        public Boolean InserirBD(Avaliacao _objeto)
        {
            bool resultado = false;
            try
            {
                String SQL = String.Format("INSERT INTO avaliacao (codigo, valor, diario_id , aluno_id) VALUES ('{0}', '{1}', '{2}', '{3}')",
                    _objeto.codigo,
                    _objeto.valor,
                    _objeto.Ava_Diario.codigo,
                    _objeto.Ava_Aluno.matricula);

                int linhaAfetadas = BD.ExecutarIDU(SQL);

                if (linhaAfetadas > 0)
                {
                    return true;
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            return resultado;
        }

        public Boolean AlterarBD(Avaliacao _objeto)
        {
            bool resultado = false;
            try
            {
                String SQL = String.Format("UPDATE avaliacao SET codigo = '{0}', valor = '{1}', diario_id = '{2}', aluno_id = '{3}'  WHERE codigo = {0};",
                    _objeto.codigo,
                    _objeto.valor,
                    _objeto.Ava_Diario.codigo,
                    _objeto.Ava_Aluno.matricula);

                int linhaAfetadas = BD.ExecutarIDU(SQL);

                if (linhaAfetadas > 0)
                {
                    return true;
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            return resultado;
        }

        public Boolean DeletarBD(Int64 _id)
        {
            bool resultado = false;
            try
            {
                String SQL = String.Format("DELETE FROM avaliacao WHERE codigo = {0};", _id);

                int linhaAfetadas = BD.ExecutarIDU(SQL);

                if (linhaAfetadas > 0)
                {
                    return true;
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            return resultado;
        }

        //INSERT COM PARAMETROS NO COMANDO E RETORNO DO ID GERADO AUTOMATICAMENTE
        public Boolean InserirBDParametros(Avaliacao _objeto)
        {
            try
            {
                //String SQL = "INSERT into tabela(nome)values(@nome); SELECT SCOPE_IDENTITY();");
                String SQL = "INSERT INTO avaliacao (codigo, valor, diario_id, aluno_id)"
                                 + "VALUES (@codigo, @valor, @diario_id, @aluno_id);";

                List<SqlCeParameter> parametros = new List<SqlCeParameter>();

                parametros.Add(new SqlCeParameter("@codigo", _objeto.codigo));
                parametros.Add(new SqlCeParameter("@valor", _objeto.valor));
                parametros.Add(new SqlCeParameter("@diario_id", _objeto.Ava_Diario));
                parametros.Add(new SqlCeParameter("@aluno_id", _objeto.Ava_Aluno));

                Int32 idInserido = BD.ExecutarInsertComRetornoID(SQL, parametros);

                if (idInserido != 0)
                {

                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
