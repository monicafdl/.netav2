﻿using System;
using System.Collections.Generic;
using System.Data.SqlServerCe;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;

namespace Dao
{
    public class AlunoDAO
    {
        public List<AlunoDAO> BuscarAlunoPorAvaliacao(Int32 _idAva)
        {
            List<AlunoDAO> listaAlunos = new List<AlunoDAO>();
            try
            {
                String SQL = String.Format("SELECT * FROM aluno WHERE estado_id = {0};", _idAva);

                SqlCeDataReader data = BD.ExecutarSelect(SQL);

                while (data.Read())
                {
                    AlunoDAO c = new AlunoDAO();

                    c.Id = data.GetInt32(0);
                    c.Descricao = data.GetString(1);

                    listaCidades.Add(c);
                }

                data.Close();
                BD.FecharConexao();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            return listaCidades;
        }

        public AlunoDAO BuscarCidadePorID(Int32 _id)
        {
            AlunoDAO c = null;
            try
            {
                String SQL = String.Format("SELECT * FROM cidade WHERE id = {0} ", _id);

                SqlCeDataReader data = BD.ExecutarSelect(SQL);

                if (data.Read())
                {
                    c = new AlunoDAO();

                    c.Id = data.GetInt32(0);
                    c.Descricao = data.GetString(1);
                }

                data.Close();
                BD.FecharConexao();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            return c;
        }

        public object Inserir(AlunoDAO _o)
        {
            throw new NotImplementedException();
        }

        public object Deletar(int p)
        {
            throw new NotImplementedException();
        }

        public object Atualizar(AlunoDAO _o)
        {
            throw new NotImplementedException();
        }
    }
}
