﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;
using System.Data.SqlServerCe;

namespace Dao
{
    public class DiarioDAO
    {

        public List<Disciplina> ListarTodos()
        {
            List<Disciplina> listaEstados = new List<Disciplina>();
            try
            {
                String SQL = "SELECT * FROM estado;";

                SqlCeDataReader data = BD.ExecutarSelect(SQL);

                while (data.Read())
                {
                    Disciplina e = new Disciplina();

                    e.Id = data.GetInt32(0);
                    e.Descricao = data.GetString(1);

                    listaEstados.Add(e);
                }

                data.Close();
                BD.FecharConexao();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            return listaEstados;
        }

        public Disciplina BuscarPorID(Int64 _id)
        {
            Disciplina e = null;
            try
            {
                String SQL = String.Format("SELECT * FROM estado WHERE id = {0} ", _id);

                SqlCeDataReader data = BD.ExecutarSelect(SQL);

                if (data.Read())
                {
                    e = new Disciplina();

                    e.Id = data.GetInt32(0);
                    e.Descricao = data.GetString(1);
                }

                data.Close();
                BD.FecharConexao();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            return e;
        }

        public object Inserir(Disciplina _o)
        {
            throw new NotImplementedException();
        }

        public object Deletar(int p)
        {
            throw new NotImplementedException();
        }

        public object Atualizar(Disciplina _o)
        {
            throw new NotImplementedException();
        }
    }
}
