﻿using Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Control;

namespace View
{
    public partial class frmCadPessoa : Form
    {
        private Pessoa p = new Pessoa();

        public frmCadPessoa()
        {
            InitializeComponent();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            try
            {
                Pessoa pessoa = CarregarPessoaDoForm();

                //Enviar objeto para camada de controle para Salvar no arquivo
                PessoaCtrl control = new PessoaCtrl();

                Boolean teste = control.InserirBD(pessoa);

                if (teste)
                {
                    MessageBox.Show("Pessoa cadastrada com sucesso!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERRO AO CADASTRAR PESSOA: " + ex.Message);
            }
            
        }

        //Carregar dados do formulário em um Novo Objeto do Tipo Pessoa
        public Pessoa CarregarPessoaDoForm()
        {
            try
            {
                //p.Id = (Int32)this.Tag;
                p.Nome = txbNome.Text;
                p.Telefone = mtbTel.Text;
                p.Email = txbEmail.Text;

                Endereco end = new Endereco();
                end.Bairro = ltbBairro.SelectedIndex.ToString();
                
                end.Logradouro = txbLogradouro.Text;

                end.Cidade.Estado.Id = Convert.ToInt32(cmbEstado.SelectedValue);
                end.Cidade.Id = Convert.ToInt32(cmbCidade.SelectedValue);

                p.Enderecos.Add(end);

                if (rdbMasculino.Checked)
                {
                    p.Sexo = "masculino";
                }
                if (rdbFeminino.Checked)
                {
                    p.Sexo = "feminino";
                }

                if (rdbCasado.Checked)
                {
                    p.EstadoCivil = "casado";
                }
                if (rdbSolteiro.Checked)
                {
                    p.EstadoCivil = "solteiro";
                }

                p.Filhos = ckbFilhos.Checked;

                p.Animais = ckbAnimais.Checked;
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERRO ao carregar usuário: " + ex.Message);
            }

            return p;
        }

        private void ptbFoto_Click(object sender, EventArgs e)
        {
            if (janelaAbrirArquivo.ShowDialog() == DialogResult.OK)
            {
                p.Imagem = janelaAbrirArquivo.FileName;
            }
        }

        private void txbNome_Click(object sender, EventArgs e)
        {
            txbNome.Text = "";
        }

        private void frmCadPessoa_Load(object sender, EventArgs e)
        {
            if (this.Tag != null &&  this.Tag is Pessoa)
            {
                btnAlterar.Visible = true;
                btnCadastrar.Visible = false;

                Pessoa p = (Pessoa)this.Tag;

                CarregarFormDePessoa(p);
            }

            CarregarEstados();
        }

        private void CarregarFormDePessoa(Pessoa p)
        {
            try
            {
                //p.Id = (Int64)this.Tag;
                txbNome.Text = p.Nome;
                mtbTel.Text = p.Telefone;
                txbEmail.Text = p.Email;
                //ltbTipoEndereco.SelectedIndex = p.TipoEndereco;
                //txbEndereco.Text = p.Endereco;
                //cmbEstado.SelectedIndex = p.Estado;
                //cmbCidade.SelectedIndex = p.Cidade;

                if (p.Sexo.Equals("masculino"))
                {
                    rdbMasculino.Checked = true;
                }
                else
                {
                    rdbFeminino.Checked = true;
                }

                if (p.EstadoCivil.Equals("casado"))
                {
                    rdbCasado.Checked = true;
                }
                else
                {
                    rdbSolteiro.Checked = true;
                }

                ckbFilhos.Checked = p.Filhos;

                ckbAnimais.Checked = p.Animais;
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERRO ao carregar o FORM: " + ex.Message);
            }
        }

        private void CarregarEstados()
        {
            try
            {
                EstadoController controle = new EstadoController();

                List<Estado> listaEstados = (List<Estado>)controle.ExecutarOpBD('t', null);

                cmbEstado.DisplayMember = "descricao";
                cmbEstado.ValueMember = "id";

                cmbEstado.DataSource = listaEstados;
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERRO: " + ex.Message);
            }
        }

        private void CarregarCidadesPorEstado(Int32 _idEstado)
        {
            try
            {
                CidadeController controle = new CidadeController();

                Cidade cidade = new Cidade();

                cidade.Estado.Id = _idEstado;

                List<Cidade> listaCidades = (List<Cidade>)controle.ExecutarOpBD('t', cidade);

                cmbCidade.DisplayMember = "descricao";
                cmbCidade.ValueMember = "id";

                cmbCidade.DataSource = listaCidades;
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERRO: " + ex.Message);
            }
        }

        private void cmbEstado_SelectedValueChanged(object sender, EventArgs e)
        {
            try
            {
                Int32 idEstado = Convert.ToInt32(cmbEstado.SelectedValue);

                CarregarCidadesPorEstado(idEstado);
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERRO: " + ex.Message);
            }
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {

        }
    }
}
