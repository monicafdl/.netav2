﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Control;
using Model;
using System.IO;

namespace View
{
    public partial class frmListaPessoas : Form
    {
        private Pessoa p;

        public frmListaPessoas()
        {
            InitializeComponent();
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmListaPessoas_Load(object sender, EventArgs e)
        {
            CarregarMapaPessoas();
        }

        private void CarregarMapaPessoas()
        {
            Dictionary<Int64, Pessoa> mapaPessoas = (Dictionary<Int64, Pessoa>)this.Tag;
            foreach (Pessoa o in mapaPessoas.Values)
            {
                dgvDados.Rows.Add(o.Id, o.Nome, o.Email);
            }
        }

        private void dgvDados_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                Int64 idPessoa = Convert.ToInt64(dgvDados.SelectedRows[0].Cells[0].Value);

                Dictionary<Int64, Pessoa> mapaPessoas = (Dictionary<Int64, Pessoa>)this.Tag;

                Pessoa p = mapaPessoas[idPessoa];

                frmCadPessoa form = new frmCadPessoa();

                form.Tag = p;

                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERRO AO SELECIONAR LINHA: " + ex.Message);
            }
        }

        private void btnImprimir_Click(object sender, EventArgs e)
        {
            try
            {
                Int64 idPessoa = Convert.ToInt64(dgvDados.SelectedRows[0].Cells[0].Value);

                Dictionary<Int64, Pessoa> mapaPessoas = (Dictionary<Int64, Pessoa>)this.Tag;

                p = mapaPessoas[idPessoa];

                if (janelaImpressao.ShowDialog() == DialogResult.OK)
                {
                    documento.Print();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("ERRO AO IMPRIMIR LINHA: " + ex.Message);
            }
        }

        private void documento_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            StringBuilder data = new StringBuilder();
            StringWriter escritor = new StringWriter(data);

            Pessoa _pessoa = p;

            escritor.WriteLine(_pessoa.Id + ";");
            escritor.WriteLine(_pessoa.Nome + ";");
            escritor.WriteLine(_pessoa.Telefone + ";");
            //escritor.WriteLine(_pessoa.TipoEndereco + ";");
            //escritor.WriteLine(_pessoa.Endereco + ";");
            //escritor.WriteLine(_pessoa.Cidade + ";");
            //escritor.WriteLine(_pessoa.Estado + ";");
            escritor.WriteLine(_pessoa.Sexo + ";");
            escritor.WriteLine(_pessoa.EstadoCivil + ";");

            if (_pessoa.Filhos)
            {
                escritor.WriteLine("Tem filhos;");
            }
            else
            {
                escritor.WriteLine("Não tem filhos;");
            }
            if (_pessoa.Animais)
            {
                escritor.WriteLine("Tem animais;");
            }
            else
            {
                escritor.WriteLine("Não tem animais;");
            }

            escritor.WriteLine();

            escritor.WriteLine(String.Format("\n\n\nData/Hora do Cadastro: {0}", DateTime.Now.ToString()));

            escritor.Close();

            float leftMargin = e.MarginBounds.Left;
            float topMargin = e.MarginBounds.Top;
            float yPos = 0;

            Font printFont = new Font("Arial", 12);
            yPos = topMargin + printFont.GetHeight(e.Graphics);
            e.HasMorePages = false;
            e.Graphics.DrawString(data.ToString(), printFont, Brushes.Black, leftMargin, yPos, new StringFormat());
        }

    }
}
