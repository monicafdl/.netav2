﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;
using System.Data.SqlServerCe;

namespace Dao
{
    public class EstadoDAO
    {

        public List<Estado> ListarTodos()
        {
            List<Estado> listaEstados = new List<Estado>();
            try
            {
                String SQL = "SELECT * FROM estado;";

                SqlCeDataReader data = BD.ExecutarSelect(SQL);

                while (data.Read())
                {
                    Estado e = new Estado();

                    e.Id = data.GetInt32(0);
                    e.Descricao = data.GetString(1);

                    listaEstados.Add(e);
                }

                data.Close();
                BD.FecharConexao();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            return listaEstados;
        }

        public Estado BuscarPorID(Int64 _id)
        {
            Estado e = null;
            try
            {
                String SQL = String.Format("SELECT * FROM estado WHERE id = {0} ", _id);

                SqlCeDataReader data = BD.ExecutarSelect(SQL);

                if (data.Read())
                {
                    e = new Estado();

                    e.Id = data.GetInt32(0);
                    e.Descricao = data.GetString(1);
                }

                data.Close();
                BD.FecharConexao();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            return e;
        }

        public object Inserir(Estado _o)
        {
            throw new NotImplementedException();
        }

        public object Deletar(int p)
        {
            throw new NotImplementedException();
        }

        public object Atualizar(Estado _o)
        {
            throw new NotImplementedException();
        }
    }
}
