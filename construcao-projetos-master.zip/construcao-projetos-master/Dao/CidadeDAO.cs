﻿using System;
using System.Collections.Generic;
using System.Data.SqlServerCe;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;

namespace Dao
{
    public class CidadeDAO
    {
        public List<Cidade> BuscarCidadesPorEstado(Int32 _idEstado)
        {
            List<Cidade> listaCidades = new List<Cidade>();
            try
            {
                String SQL = String.Format("SELECT * FROM cidade WHERE estado_id = {0};", _idEstado);

                SqlCeDataReader data = BD.ExecutarSelect(SQL);

                while (data.Read())
                {
                    Cidade c = new Cidade();

                    c.Id = data.GetInt32(0);
                    c.Descricao = data.GetString(1);

                    listaCidades.Add(c);
                }

                data.Close();
                BD.FecharConexao();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            return listaCidades;
        }

        public Cidade BuscarCidadePorID(Int32 _id)
        {
            Cidade c = null;
            try
            {
                String SQL = String.Format("SELECT * FROM cidade WHERE id = {0} ", _id);

                SqlCeDataReader data = BD.ExecutarSelect(SQL);

                if (data.Read())
                {
                    c = new Cidade();

                    c.Id = data.GetInt32(0);
                    c.Descricao = data.GetString(1);
                }

                data.Close();
                BD.FecharConexao();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            return c;
        }

        public object Inserir(Cidade _o)
        {
            throw new NotImplementedException();
        }

        public object Deletar(int p)
        {
            throw new NotImplementedException();
        }

        public object Atualizar(Cidade _o)
        {
            throw new NotImplementedException();
        }
    }
}
