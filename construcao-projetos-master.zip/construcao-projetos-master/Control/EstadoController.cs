﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;
using Dao;

namespace Control
{
    public class EstadoController
    {
        public Object ExecutarOpBD(char _c, Estado _o)
        {
            try
            {
                EstadoDAO dao = new EstadoDAO();
                switch (_c)
                {
                    case 'i':
                        return dao.Inserir(_o);
                    case 'd':
                        return dao.Deletar(_o.Id);
                    case 'a':
                        return dao.Atualizar(_o);
                    case 't':
                        return dao.ListarTodos();
                    case 'o':
                        return dao.BuscarPorID(_o.Id);
                    default:
                        return null;
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
