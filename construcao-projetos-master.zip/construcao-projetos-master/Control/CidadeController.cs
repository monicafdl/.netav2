﻿using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dao;

namespace Control
{
    public class CidadeController
    {
        public Object ExecutarOpBD(char _c, Cidade _o)
        {
            try
            {
                Int32 idEstado = _o.Estado.Id;

                CidadeDAO dao = new CidadeDAO();
                switch (_c)
                {
                    case 'i':
                        return dao.Inserir(_o);
                    case 'd':
                        return dao.Deletar(_o.Id);
                    case 'a':
                        return dao.Atualizar(_o);
                    case 't':
                        return dao.BuscarCidadesPorEstado(idEstado);
                    case 'o':
                        return dao.BuscarCidadePorID(_o.Id);
                    default:
                        return null;
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
