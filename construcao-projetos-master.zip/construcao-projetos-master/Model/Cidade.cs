﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class Cidade
    {
        public Int32 Id { get; set; }

        public String Descricao { get; set; }

        public Estado Estado { get; set; }

        public Cidade()
        {
            this.Estado = new Estado();
        }
    }
}
