﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class Pessoa
    {
        #region Atributos

        public Int32 Id { set; get; }
        
        //Declaração Implícita
        public String Nome { set; get; }

        //Declaração explícita
        
        private String telefone;
        public String Telefone
        {
            get { return telefone; }
            set { telefone = value; }
        }
        
        //public Telefone Telefone { set; get; }

        public String Email { set; get; }

        public String Imagem { set; get; }
        
        public String Sexo { set; get; }

        public String EstadoCivil { set; get; }

        public Boolean Animais { set; get; }

        public Boolean Filhos { set; get; }

        public List<Endereco> Enderecos { get; set; }

        #endregion

        #region Métodos
         //Implementação dos métodos
        public Pessoa()
        {
            this.Enderecos = new List<Endereco>();
        }

        #endregion
    }
}
