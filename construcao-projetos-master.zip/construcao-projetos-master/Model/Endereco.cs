﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class Endereco
    {
        public Int32 Id { get; set; }

        public String Logradouro { get; set; }

        public String Numero { get; set; }

        public String Bairro { get; set; }

        public Cidade Cidade { get; set; }

        public Endereco()
        {
            this.Cidade = new Cidade();
        }
    }
}
